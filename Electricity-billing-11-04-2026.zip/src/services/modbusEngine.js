const ModbusRTU = require('modbus-serial');
const prisma = require('../config/prisma');

class ModbusEngine {
    constructor() {
        this.clients = new Map();
        this.io = null;
        this.isPolling = false;
    }

    init(io) {
        this.io = io;
        console.log('[Modbus] Engine initialized. Starting polling loop...');
        // Start polling after a short delay to ensure everything is ready
        setTimeout(() => this.startPolling(), 2000);
    }

    async connectToMeter(meter) {
        let client = this.clients.get(meter.id);
        if (client && client.isOpen) return client;

        client = new ModbusRTU();
        try {
            if (meter.connectionType === 'TCP') {
                const port = Number(meter.port) || 502;
                console.log(`[Modbus] Attempting TCP connection to ${meter.ipAddress}:${port} (Meter: ${meter.meterId})`);
                await client.connectTCP(meter.ipAddress, { port });
            } else {
                console.log(`[Modbus] Attempting RTU connection to ${meter.comPort} (Meter: ${meter.meterId})`);
                await client.connectRTUBuffered(meter.comPort, {
                    baudRate: Number(meter.baudRate) || 9600,
                    dataBits: Number(meter.dataBits) || 8,
                    stopBits: Number(meter.stopBits) || 1,
                    parity: meter.parity || 'none'
                });
            }
            client.setID(Number(meter.modbusAddress) || 1);
            client.setTimeout(5000); // Increased timeout for reliability
            this.clients.set(meter.id, client);
            console.log(`[Modbus] ✅ Connected to Meter: ${meter.meterId}`);
            return client;
        } catch (error) {
            console.error(`[Modbus] ❌ Connection Error (${meter.meterId}):`, error.message);
            throw error; // Throw so we can capture the message
        }
    }

    async readMeterData(meter) {
        try {
            let client;
            try {
                client = await this.connectToMeter(meter);
            } catch (connErr) {
                return { status: 'Disconnected', error: connErr.message };
            }

            if (!client) {
                return { status: 'Disconnected', error: 'Could not establish connection' };
            }

            const results = { status: 'Connected' };

            // Real physical reading logic
            if (!meter.registers || meter.registers.length === 0) {
                 console.warn(`[Modbus] No registers defined for Meter: ${meter.meterId}`);
                 return { status: 'Connected', error: 'No registers configured', Voltage: 0, Current: 0, Energy: 0, Power: 0 };
            }

            for (const reg of meter.registers) {
                try {
                    let data;
                    const regAddress = parseInt(reg.address);
                    const regCount = (reg.dataType === 'Float' || reg.dataType === 'Int32') ? 2 : 1;
                    
                    if (Number(reg.functionCode) === 3) {
                        data = await client.readHoldingRegisters(regAddress, regCount);
                    } else {
                        data = await client.readInputRegisters(regAddress, regCount);
                    }

                    if (data && (data.buffer || data.data)) {
                        const key = reg.label;
                        if (reg.dataType === 'Float' && data.buffer) {
                             results[key] = parseFloat(data.buffer.readFloatBE(0).toFixed(2));
                        } else if (reg.dataType === 'Int32' && data.buffer) {
                             results[key] = data.buffer.readInt32BE(0);
                        } else if (data.data) {
                             results[key] = data.data[0];
                        }
                    }
                } catch (err) {
                    console.warn(`[Modbus] Field ${reg.label} failed for ${meter.meterId}: ${err.message}`);
                    results[reg.label] = 0;
                }
            }
            return results;
        } catch (error) {
            console.error(`[Modbus] Read Error (${meter.meterId}):`, error.message);
            return { status: 'Disconnected', error: error.message };
        }
    }

    async startPolling() {
        if (this.isPolling) return;
        this.isPolling = true;

        const interval = Number(process.env.POLLING_INTERVAL_MS) || 5000;
        console.log(`[Modbus] Polling loop started every ${interval}ms`);

        const poll = async () => {
            try {
                const meters = await prisma.meter.findMany({
                    include: {
                        registers: true,
                        consumer: { include: { user: { select: { name: true } } } }
                    }
                });

                for (const meter of meters) {
                    const reading = await this.readMeterData(meter);
                    
                    if (!reading || reading.status === 'Disconnected') {
                        console.warn(`[Modbus] [${meter.meterId}] Meter is Offline or Unreachable`);
                        
                        // Update status to failed in DB
                        await prisma.meter.update({
                            where: { id: meter.id },
                            data: { status: 'Disconnected' }
                        }).catch(() => {});

                        // Notify UI of disconnection
                        if (this.io) {
                            this.io.emit('meterUpdate', {
                                meterId: meter.meterId,
                                meterName: meter.meterName,
                                consumerName: meter.consumer?.user?.name || 'Unknown',
                                status: 'Disconnected',
                                lastUpdated: new Date()
                            });
                        }
                        continue;
                    }

                    // Normalize data
                    const normalized = {
                        voltage: parseFloat(reading.Voltage || reading.voltage || 0),
                        current: parseFloat(reading.Current || reading.current || 0),
                        energy: parseFloat(reading.Energy || reading.energy || reading.KWH || 0),
                        power: parseFloat(reading.Power || reading.power || reading.KW || 0)
                    };

                    console.log(`[Modbus] [${meter.meterId}] New Live Data:`, normalized);

                    try {
                        // CRITICAL: Database update
                        await prisma.$transaction([
                            prisma.meterReading.create({
                                data: {
                                    meterId: meter.id,
                                    voltage: normalized.voltage,
                                    current: normalized.current,
                                    energy: normalized.energy,
                                    power: normalized.power,
                                    status: 'Online'
                                }
                            }),
                            prisma.meter.update({
                                where: { id: meter.id },
                                data: { status: 'Active', lastUpdated: new Date() }
                            }),
                            prisma.consumer.update({
                                where: { id: meter.consumerId },
                                data: { lastReading: normalized.energy, updatedAt: new Date() }
                            })
                        ]);

                        // Socket emission for Live UI
                        if (this.io) {
                            this.io.emit('meterUpdate', {
                                meterId: meter.meterId,
                                meterName: meter.meterName,
                                consumerName: meter.consumer?.user?.name || 'Unknown',
                                ...normalized,
                                ...reading, // Include all other dynamic registers
                                status: 'Active',
                                lastUpdated: new Date()
                            });
                        }
                    } catch (dbError) {
                        console.error(`[DB] ❌ Failed to save data for ${meter.meterId}:`, dbError.message);
                    }
                }
            } catch (error) {
                console.error('[Modbus] Critical Loop Error:', error.message);
            } finally {
                setTimeout(poll, interval);
            }
        };

        poll();
    }
}

module.exports = new ModbusEngine();